import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  username:string='rama';
  password:string='ravi';

  constructor() { }

  ngOnInit(): void {
  }
  fnLogin()
  {
  //  alert(this.username+" and "+this.password); 
    console.log(this.username);
  }
}

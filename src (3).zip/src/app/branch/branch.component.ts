import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { BranchService } from '../branch.service';

@Component({
  selector: 'app-branch',
  templateUrl: './branch.component.html',
  styleUrls: ['./branch.component.css']
})
export class BranchComponent implements OnInit {
  branchForm:any;
  branches:any;
  branch:any;
  constructor(private fb:FormBuilder, private bs:BranchService) 
  {
    this.branchForm=this.fb.group({
      bid:['',Validators.required],
      bname:[''],
      bcity:['']
    });
  }

  ngOnInit(): void {
    this.bs.getAllBranches().subscribe(data=>{
      this.branches=data;
    });
  }

  fnSelect(bid:string)
  {
    this.bs.findBranchById(bid).subscribe(data=>{
      this.branchForm.patchValue(data);
    });    
  }

  fnAdd(){
    this.bs.addBranch(this.branchForm.value).subscribe(data=>console.log(data));
  }
  fnModify(){
    this.bs.modifyBranch(this.branchForm.value).subscribe(data=>console.log(data));
  }
  fnDelete(){
    // alert(this.branchForm.value.bid);
    this.bs.deleteBranch(this.branchForm.value.bid).subscribe(data=>console.log(data));
  }
}

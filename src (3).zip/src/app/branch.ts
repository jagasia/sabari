export class Branch {
    bid : string='';
    bname : string='';
    bcity : string='';
}

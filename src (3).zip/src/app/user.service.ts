import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  url:string='https://jsonplaceholder.typicode.com/todos';

  constructor(private http:HttpClient) { }

  getAllUsers()
  {
    return this.http.get(this.url);
  }

  findUserById(id)
  {
    return this.http.get(this.url+"/"+id);
  }

}

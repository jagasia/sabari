export class User {
    username:string;
	password:string;
	cpassword:string;
	firstName:string;
	lastName:string;
	emailId:string;
	phoneNo:string;
}

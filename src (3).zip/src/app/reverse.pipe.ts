import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'reverse'
})
export class ReversePipe implements PipeTransform {

  transform(value: string, ...args: unknown[]): unknown {
    // (this.dummy.split('').reverse().join('')).toString();
    return (value.split('').reverse().join('')).toString();;
  }

}

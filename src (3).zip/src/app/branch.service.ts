import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Branch } from './branch';

@Injectable({
  providedIn: 'root'
})
export class BranchService {
  // url:string='http://third-env.eba-mt8mpdcn.ap-south-1.elasticbeanstalk.com/branch';
  // url:string="http://localhost:5000/branch";
    url:string="http://localhost:9000/branch";

  constructor(private http:HttpClient) { }

  getAllBranches()
  {
    return this.http.get(this.url);
  }
  findBranchById(bid : string)
  {
    return this.http.get(this.url+"/"+bid);
  }
  addBranch(branch:Branch)
  {
    return this.http.post(this.url,branch);
  }
  modifyBranch(branch:Branch)
  {
    return this.http.put(this.url,branch);
  }
  deleteBranch(bid:string)
  {
    return this.http.delete(this.url+"/"+bid);
  }
}

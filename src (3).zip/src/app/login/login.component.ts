import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
// import { EventEmitter } from 'stream';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  username:string='rama';
  password:string='ravi';
  @Input() heading1:string;

  // @Output() loginEvent:EventEmitter<string>=new EventEmitter();
  @Output() loginEvent:EventEmitter<string>=new EventEmitter();

  constructor() { }

  ngOnInit(): void {
  }
  fnLogin()
  {
  //  alert(this.username+" and "+this.password); 
    console.log(this.username);
    this.loginEvent.emit(this.username);
  }
}
